package com.cg.librarian.exception;

public class LibrarianException extends Exception{
	public LibrarianException(String obj){
		System.out.println(obj);
	}

}
